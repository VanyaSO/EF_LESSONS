CREATE TRIGGER NewIceCreamAfterInsertFlavor 
ON IceCreamFlavors
AFTER INSERT
AS
    BEGIN   
        DECLARE @idFlavor int, @nameFlavor nvarchar(255), @maxIdIceCream int;

        SELECT @maxIdIceCream = MAX(ID) FROM IceCreams;
        SELECT @idFlavor = ID, @nameFlavor = Name FROM Inserted;
        INSERT INTO IceCreams (ID, Name, Price, StockQuantity, IceCreamFlavorID) 
        VALUES (@maxIdIceCream+1, CONCAT(@nameFlavor, ' Classic'), 0, 0, @idFlavor)
    END
go

