CREATE TRIGGER IceCreamsLogsTrigger
ON IceCreams
AFTER INSERT, UPDATE, DELETE
AS 
    DECLARE @description nvarchar(max);

    IF EXISTS(SELECT * FROM Inserted) AND NOT EXISTS(SELECT * FROM Deleted)
    BEGIN 
        SET @description = 'Insert ice cream';
    END
    ELSE IF EXISTS(SELECT * FROM Inserted) AND EXISTS(SELECT * FROM Deleted)
    BEGIN 
        SET @description = 'Update ice cream';
    END

    INSERT INTO IceCreamsLogs (Description) VALUES (@description);
go

